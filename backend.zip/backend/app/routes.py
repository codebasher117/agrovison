from flask import Blueprint, request, jsonify
import pandas as pd
from .plot_utils import generate_all_graphs

main = Blueprint('main', __name__)

# Load Excel once on startup
xls = pd.ExcelFile("crop_yield_data.xlsx")
data = {sheet: xls.parse(sheet).dropna() for sheet in xls.sheet_names}

@main.route("/districts", methods=["GET"])
def get_districts():
    return jsonify({"states": {"Assam": list(data.keys())}})

@main.route("/dashboard", methods=["POST"])
def dashboard_data():
    req = request.json
    district = req.get("district")
    year = int(req.get("year"))

    if district not in data:
        return jsonify({"error": "District not found"}), 404

    df = data[district]
    graphs = generate_all_graphs(df, year, district)

    return jsonify(graphs)
