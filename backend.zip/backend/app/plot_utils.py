import pandas as pd
import plotly.graph_objects as go
import base64
from io import BytesIO

months = ['June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
month_nums = ['6', '7', '8', '9', '10', '11', '12']

def fig_to_base64(fig):
    buf = BytesIO()
    fig.write_image(buf, format="png")
    encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{encoded}"

def generate_all_graphs(df, year, district):
    df_year = df[df["year"] == year]
    baseline = df[df["year"].between(2015, 2019)]

    results = {}

    # Yield Status
    yield_val = df_year['yield'].values[0]
    q25, q75 = df['yield'].quantile(0.25), df['yield'].quantile(0.75)
    status = "Good" if yield_val >= q75 else "Risk" if yield_val <= q25 else "Moderate"
    results["yield_status"] = {
        "value": round(yield_val, 2),
        "category": status
    }

    # Climate Deviation Warning
    monsoon_cols = [f"precip_flux_{m}" for m in month_nums]
    current_vals = df_year[monsoon_cols].values.flatten()
    past_avg = df[df['year'].between(year - 5, year - 1)][monsoon_cols].mean().values
    deviation = abs(current_vals - past_avg) / (past_avg + 1e-5)
    results["climate_warning"] = "Significant" if (deviation > 0.25).any() else "Normal"

    # Line Plot
    var_prefix_map = {
        "temp": "Temperature (°C)",
        "humidity": "Humidity (%)",
        "et0": "ET₀ (mm/day)",
        "precip_flux": "Rainfall (mm/day)",
        "tmax": "Max Temp (°C)",
        "tmin": "Min Temp (°C)"
    }
    fig = go.Figure()
    for prefix, label in var_prefix_map.items():
        cols = [f"{prefix}_{m}" for m in month_nums if f"{prefix}_{m}" in df.columns]
        if not cols:
            continue
        values = df_year[cols].values.flatten()
        fig.add_trace(go.Scatter(x=months[:len(values)], y=values, mode="lines+markers", name=label))

    fig.add_trace(go.Scatter(
        x=months, y=[yield_val]*len(months),
        mode="lines", name=f"Yield: {yield_val:.2f} tons/ha",
        line=dict(dash='dash', color='green'), yaxis='y2'
    ))

    fig.update_layout(
        title=f"Climate Trend – {district}, {year}",
        xaxis_title="Month",
        yaxis=dict(title="Climate"),
        yaxis2=dict(title="Yield", overlaying='y', side='right'),
        legend=dict(orientation="v"),
        height=500
    )

    results["climate_trend"] = fig_to_base64(fig)

    # Add more figures similarly...
    return results
