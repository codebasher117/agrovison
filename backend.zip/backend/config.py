EXCEL_FILE = "crop_yield_data.xlsx"
